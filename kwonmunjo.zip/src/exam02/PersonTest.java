package exam02;

public class PersonTest {

	public static void main(String[] args) {
		Person p = new Person();
		Customer c = new Customer();
		
		System.out.println(p);
		System.out.println(c);
	}

}
