package chapter0703;

public class Audio extends Product{

	Audio() {
		super(300);
	}

	@Override
	public String toString() {
		return "�����";
	}
	
	
}
