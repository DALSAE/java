package chapter0703;

public class Computer extends Product {
	Computer(){
		super(200);
	}

	@Override
	public String toString() {
		return "��ǻ��";
	}

}
