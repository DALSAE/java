package chapter0703;

public class Piano extends Product {
	Piano(){
		super(300);
	}

	@Override
	public String toString() {
		return "�ǾƳ�";
	}

}
