package chapter0703;

public class Tv extends Product {
	Tv(){
		super(100);
		
	}

	@Override
	public String toString() {
		return "Ƽ��";
	}

}
