package chapter07;

public class Parent {
	int x = 10;
	

}
