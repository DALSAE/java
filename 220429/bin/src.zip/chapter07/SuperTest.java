package chapter07;

public class SuperTest {

	public static void main(String[] args) {
		Child c =new Child();
		c.method();
	}

}
