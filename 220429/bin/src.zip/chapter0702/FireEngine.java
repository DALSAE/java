package chapter0702;

public class FireEngine extends Car{
	void water() {
		System.out.println("Water---");
	}
}
