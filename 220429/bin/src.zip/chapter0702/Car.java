package chapter0702;

public class Car {
	String color;
	int door;
	
	void drive() {
		System.out.println("Drive~~");
	}
	void stop() {
		System.out.println("Stop!!");
	}
	

}
