package chapter0702;

public class Child extends Parent {
	int x=200;
	

	void method() {
		System.out.println("Child Method");
	}

}
