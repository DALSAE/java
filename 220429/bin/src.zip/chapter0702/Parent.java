package chapter0702;

public class Parent {
	int x =100;
	void method() {
		System.out.println("Patent Method");
	}

}
